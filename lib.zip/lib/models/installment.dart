class Installment {
  final String id;
  final String monthName;
  final double amount;
  final double paidAmount;
  final String status;

  Installment({
    required this.id,
    required this.monthName,
    required this.amount,
    required this.paidAmount,
    required this.status,
  });

  factory Installment.fromJson(
      Map<String, dynamic> json,
      ) {
    return Installment(
      id: json['id'],
      monthName: json['month_name'] ?? '',
      amount: double.tryParse(
        json['amount'].toString(),
      ) ??
          0,
      paidAmount: double.tryParse(
        json['paid_amount'].toString(),
      ) ??
          0,
      status: json['status'] ?? 'unpaid',
    );
  }

  bool get isPaid => status == 'paid';
}