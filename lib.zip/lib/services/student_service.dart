import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/etudiant.dart';
import '../models/installment.dart';

class StudentService {
  final supabase = Supabase.instance.client;

  Future<Student> getStudentById(
      String id,
      ) async {
    final response = await supabase
        .from('students')
        .select('*, filieres(*)')
        .eq('id', id)
        .single();

    return Student.fromJson(response);
  }

  Future<Student> getStudentByQr(
      String qrCode,
      ) async {
    final response = await supabase
        .from('students')
        .select('*, filieres(*)')
        .eq('qr_code', qrCode)
        .single();

    return Student.fromJson(response);
  }

  Future<List<Student>> getStudents() async {
    final response = await supabase
        .from('students')
        .select('*, filieres(*)')
        .order('first_name');

    return response
        .map<Student>(
          (e) => Student.fromJson(e),
    )
        .toList();
  }

  Future<List<Installment>>
  getInstallments(
      String studentId,
      ) async {
    final response = await supabase
        .from('tuition_installments')
        .select()
        .eq('student_id', studentId);

    return response
        .map<Installment>(
          (e) => Installment.fromJson(e),
    )
        .toList();
  }

  Future<double> getRemainingAmount(
      String studentId,
      ) async {
    final installments =
    await getInstallments(studentId);

    double total = 0;

    for (final item in installments) {
      total +=
          item.amount - item.paidAmount;
    }

    return total;
  }

  Future<bool> isStudentUpToDate(
      String studentId,
      ) async {
    final installments =
    await getInstallments(studentId);

    return installments.every(
          (item) => item.status == 'paid',
    );
  }
}